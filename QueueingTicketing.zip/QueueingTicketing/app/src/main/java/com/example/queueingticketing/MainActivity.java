package com.example.queueingticketing;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends Activity {

    private final int MAROON = Color.rgb(128, 0, 32);
    private final int BLACK = Color.BLACK;
    private final int WHITE = Color.WHITE;

    private static final long FIVE_MINUTES =
            5 * 60 * 1000L;

    private QueueDatabase database;
    private String currentEmail = "";
    private String selectedWindow = "CTC";
    private int currentTicket = 1;

    private LinearLayout root;
    private TextView timerText;

    private final Handler timerHandler =
            new Handler(Looper.getMainLooper());

    private Runnable timerRunnable;
    private long deadlineMillis;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        database = new QueueDatabase(this);

        showLogin();
    }

    // ---------- DESIGN HELPERS ----------

    private int dpToPx(int dp) {
        return Math.round(dp * getResources().getDisplayMetrics().density);
    }

    private GradientDrawable shape(
            int color, int strokeColor, int radiusDp) {

        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dpToPx(radiusDp));

        if (strokeColor != 0) {
            drawable.setStroke(dpToPx(2), strokeColor);
        }

        return drawable;
    }

    private TextView text(
            String value, int size, int color, boolean bold) {

        TextView view = new TextView(this);

        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setGravity(Gravity.CENTER);
        view.setPadding(dpToPx(8), dpToPx(6), dpToPx(8), dpToPx(6));

        if (bold) {
            view.setTypeface(null, Typeface.BOLD);
        }

        return view;
    }

    private Button button(String label, Runnable action) {

        Button button = new Button(this);

        button.setText(label);
        button.setTextColor(WHITE);
        button.setTextSize(15);
        button.setAllCaps(false);
        button.setGravity(Gravity.CENTER);
        button.setPadding(0, 0, 0, 0);
        button.setBackground(shape(MAROON, 0, 12));

        button.setOnClickListener(v -> action.run());

        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        dpToPx(48)
                );

        params.setMargins(dpToPx(4), dpToPx(5), dpToPx(4), dpToPx(5));
        button.setLayoutParams(params);

        return button;
    }

    private EditText field(String hint, boolean password) {

        EditText editText = new EditText(this);

        editText.setSingleLine(true);
        editText.setHint(hint);
        editText.setHintTextColor(Color.GRAY);
        editText.setTextColor(BLACK);
        editText.setTextSize(15);
        editText.setPadding(dpToPx(16), dpToPx(8), dpToPx(16), dpToPx(8));
        editText.setBackground(shape(WHITE, MAROON, 10));

        if (password) {
            editText.setInputType(129);
        } else {
            editText.setInputType(33);
        }

        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        dpToPx(48)
                );

        params.setMargins(dpToPx(4), dpToPx(5), dpToPx(4), dpToPx(5));
        editText.setLayoutParams(params);

        return editText;
    }

    private void startScreen(String title, String subtitle) {

        stopTimerUpdates();

        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        scrollView.setBackgroundColor(WHITE);

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dpToPx(20), dpToPx(16), dpToPx(20), dpToPx(24));

        root.addView(text(
                "ONLINE QUEUEING / TICKETING",
                16, BLACK, true
        ));

        TextView logo = text("Q", 28, WHITE, true);
        logo.setBackground(shape(MAROON, 0, 14));
        logo.setPadding(0, 0, 0, 0);

        LinearLayout.LayoutParams logoParams =
                new LinearLayout.LayoutParams(dpToPx(56), dpToPx(56));

        logoParams.setMargins(0, dpToPx(12), 0, dpToPx(6));
        logo.setLayoutParams(logoParams);

        root.addView(logo);
        root.addView(text(title, 22, MAROON, true));
        root.addView(text(subtitle, 14, BLACK, false));

        scrollView.addView(root, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT,
                ScrollView.LayoutParams.WRAP_CONTENT
        ));

        setContentView(scrollView);
    }

    // ---------- LOGIN ----------

    private void showLogin() {

        startScreen(
                "Welcome Back",
                "Please sign in to continue."
        );

        EditText email = field("Email address", false);
        email.setText("demo@example.com");

        EditText password = field("Password", true);
        password.setText("password123");

        root.addView(email);
        root.addView(password);

        root.addView(text(
                "Demo: demo@example.com / password123",
                12, MAROON, false
        ));

        root.addView(button("Sign In", () -> {

            String enteredEmail =
                    email.getText().toString().trim();

            String enteredPassword =
                    password.getText().toString();

            if (database.login(
                    enteredEmail, enteredPassword)) {

                currentEmail = enteredEmail;
                showWindowSelection();

            } else {
                Toast.makeText(
                        this,
                        "Incorrect email or password.",
                        Toast.LENGTH_LONG
                ).show();
            }
        }));

        root.addView(button("Create Account", this::showSignup));
    }

    private void showSignup() {

        startScreen(
                "Create Account",
                "Register a new account."
        );

        EditText email = field("Email address", false);
        EditText password = field(
                "Password (at least 6 characters)", true
        );

        root.addView(email);
        root.addView(password);

        root.addView(button("Register", () -> {

            String enteredEmail =
                    email.getText().toString().trim();

            String enteredPassword =
                    password.getText().toString();

            if (enteredEmail.isEmpty()
                    || enteredPassword.length() < 6) {

                Toast.makeText(
                        this,
                        "Enter an email and a password of at least 6 characters.",
                        Toast.LENGTH_LONG
                ).show();

            } else if (database.register(
                    enteredEmail, enteredPassword)) {

                currentEmail = enteredEmail;
                showWindowSelection();

            } else {
                Toast.makeText(
                        this,
                        "This email may already be registered.",
                        Toast.LENGTH_LONG
                ).show();
            }
        }));

        root.addView(button("Back to Sign In", this::showLogin));
    }

    // ---------- SELECT SERVICE WINDOW ----------

    private void selectWindowAndGetTicket(String windowCode) {

        selectedWindow = windowCode;

        currentTicket = database.getOrCreateUserTicket(
                currentEmail,
                selectedWindow
        );

        Toast.makeText(
                this,
                "Ticket #" + currentTicket + " assigned by system for Window (" + selectedWindow + ")",
                Toast.LENGTH_SHORT
        ).show();

        showQueue();
    }

    private void showWindowSelection() {

        startScreen(
                "Select a Window",
                "Tap a window to automatically get your queue number."
        );

        root.addView(button("Window 1 — CTC", () -> selectWindowAndGetTicket("CTC")));

        root.addView(button("Window 2 — COR", () -> selectWindowAndGetTicket("COR")));

        root.addView(button("Sign Out", this::showLogin));
    }

    // ---------- QUEUE SCREEN ----------

    private void showQueue() {

        // Auto-call the earliest waiting ticket in FCFS order if the window is open
        database.autoCallNextWaitingTicket(selectedWindow);

        startScreen(
                "Queue Numbers",
                "Window: " + selectedWindow
        );

        String status = database.getStatus(
                selectedWindow, currentTicket
        );

        TextView current = text(
                "YOUR TICKET: " + currentTicket +
                        "\nSTATUS: " + status,
                18, WHITE, true
        );

        current.setBackground(shape(MAROON, 0, 14));
        root.addView(current);

        timerText = text(
                "Timer starts when your number is called.",
                16, MAROON, true
        );

        timerText.setBackground(shape(WHITE, MAROON, 14));
        root.addView(timerText);

        // Show the first 8 queue numbers.
        for (int start = 1; start <= 8; start += 2) {

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);

            for (int n = start; n <= start + 1; n++) {

                final int number = n;

                String ticketStatus = database.getStatus(
                        selectedWindow, number
                );

                boolean isUserTicket = (number == currentTicket);
                boolean called = "Called".equals(ticketStatus);
                boolean late = "Late".equals(ticketStatus);
                boolean arrived = "Arrived".equals(ticketStatus);
                boolean waiting = "Waiting".equals(ticketStatus);

                String label = "QUEUE " + number + "\n" + ticketStatus;
                if (isUserTicket && !"Available".equals(ticketStatus)) {
                    label += " (YOU)";
                }

                int bg;
                int textColor;

                if (called || late) {
                    bg = BLACK;
                    textColor = WHITE;
                } else if (arrived) {
                    bg = MAROON;
                    textColor = WHITE;
                } else if (waiting) {
                    bg = WHITE;
                    textColor = BLACK;
                } else { // Available
                    bg = WHITE;
                    textColor = Color.GRAY;
                }

                TextView tile = text(label, 13, textColor, true);
                tile.setBackground(shape(bg, MAROON, 12));

                LinearLayout.LayoutParams params =
                        new LinearLayout.LayoutParams(0, dpToPx(70), 1);

                params.setMargins(dpToPx(3), dpToPx(3), dpToPx(3), dpToPx(3));
                row.addView(tile, params);
            }

            root.addView(row);
        }

        root.addView(text(
                "Tickets are automatically called in First-Come, First-Served (FCFS) order by the system.",
                12, BLACK, false
        ));

        // Stop timer and confirm the user arrived.
        root.addView(button("Arrived at Window", () -> {

            String currentStatus = database.getStatus(
                    selectedWindow, currentTicket
            );

            if (!"Called".equals(currentStatus)) {

                Toast.makeText(
                        this,
                        "Your ticket (#" + currentTicket + ") must be called first.",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            stopTimerUpdates();

            database.markArrived(
                    selectedWindow, currentTicket
            );

            Toast.makeText(
                    this,
                    "Arrival confirmed. Timer stopped.",
                    Toast.LENGTH_LONG
            ).show();

            showQueue();
        }));

        root.addView(button("Service Complete", () -> {

            String currentStatus = database.getStatus(
                    selectedWindow, currentTicket
            );

            if ("Available".equals(currentStatus)) {
                Toast.makeText(
                        this,
                        "Your ticket is not active or has already been completed.",
                        Toast.LENGTH_SHORT
                ).show();
                return;
            }

            stopTimerUpdates();

            database.completeTicket(
                    selectedWindow, currentTicket
            );

            showServiceComplete();
        }));

        root.addView(button(
                "Back to Window Selection",
                this::showWindowSelection
        ));

        // Restore the timer based on the saved call timestamp.
        if ("Called".equals(status)) {
            startArrivalTimer();

        } else if ("Late".equals(status)) {
            timerText.setText("00:00 — TICKET LATE");

        } else if ("Arrived".equals(status)) {
            timerText.setText("ARRIVAL CONFIRMED");

        } else if ("Completed".equals(status) || "Available".equals(status)) {
            timerText.setText("NO ACTIVE CALL");
        }
    }

    // ---------- AUTOMATIC 5-MINUTE TIMER ----------

    private void startArrivalTimer() {

        stopTimerUpdates();

        long calledAt = database.getCalledAt(
                selectedWindow, currentTicket
        );

        if (calledAt <= 0) {
            timerText.setText("Waiting for call.");
            return;
        }

        // Deadline is based on the original call time.
        deadlineMillis = calledAt + FIVE_MINUTES;

        timerRunnable = new Runnable() {
            @Override
            public void run() {

                String status = database.getStatus(
                        selectedWindow, currentTicket
                );

                // Stop if the user arrived or ticket was changed.
                if (!"Called".equals(status)) {
                    return;
                }

                long remaining =
                        deadlineMillis - System.currentTimeMillis();

                if (remaining <= 0) {

                    database.markLate(
                            selectedWindow, currentTicket
                    );

                    timerText.setText("00:00 — TICKET LATE");

                    Toast.makeText(
                            MainActivity.this,
                            "Queue " + currentTicket +
                                    " is late. Please check the window.",
                            Toast.LENGTH_LONG
                    ).show();

                    showQueue();
                    return;
                }

                long totalSeconds = remaining / 1000;
                long minutes = totalSeconds / 60;
                long seconds = totalSeconds % 60;

                timerText.setText(String.format(
                        Locale.getDefault(),
                        "TIME REMAINING: %02d:%02d",
                        minutes,
                        seconds
                ));

                timerHandler.postDelayed(this, 1000);
            }
        };

        timerHandler.post(timerRunnable);
    }

    private void stopTimerUpdates() {

        if (timerRunnable != null) {
            timerHandler.removeCallbacks(timerRunnable);
            timerRunnable = null;
        }
    }

    // ---------- COMPLETION SCREENS ----------

    private void showServiceComplete() {

        startScreen(
                "Service Complete",
                "Your transaction has been completed."
        );

        root.addView(text(
                "✓",
                50, MAROON, true
        ));

        root.addView(text(
                "Thank you for waiting.",
                16, BLACK, false
        ));

        root.addView(button("Done", this::showVisitComplete));
    }

    private void showVisitComplete() {

        startScreen(
                "Visit Complete",
                "Thank you for using our system."
        );

        TextView message = text(
                "THANK YOU!\n\nWe look forward to serving you again.",
                20, WHITE, true
        );

        message.setBackground(shape(BLACK, 0, 14));

        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        dpToPx(140)
                );

        params.setMargins(0, dpToPx(20), 0, dpToPx(20));
        root.addView(message, params);

        root.addView(button("Return to Sign In", this::showLogin));
    }

    @Override
    protected void onDestroy() {
        stopTimerUpdates();
        super.onDestroy();
    }
}
