package com.example.queueingticketing;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.HashSet;
import java.util.Set;

public class QueueDatabase extends SQLiteOpenHelper {

    private static final String DB_NAME = "queueing.db";
    private static final int DB_VERSION = 2;

    public QueueDatabase(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL(
                "CREATE TABLE users (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "email TEXT UNIQUE NOT NULL, " +
                        "password TEXT NOT NULL)"
        );

        db.execSQL(
                "CREATE TABLE tickets (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "user_email TEXT NOT NULL, " +
                        "window_code TEXT NOT NULL, " +
                        "queue_number INTEGER NOT NULL, " +
                        "status TEXT NOT NULL DEFAULT 'Waiting', " +
                        "called_at INTEGER DEFAULT 0)"
        );

        ContentValues demo = new ContentValues();
        demo.put("email", "demo@example.com");
        demo.put("password", "password123");

        db.insert("users", null, demo);
    }

    @Override
    public void onUpgrade(
            SQLiteDatabase db,
            int oldVersion,
            int newVersion) {

        if (oldVersion < 2) {
            db.execSQL(
                    "ALTER TABLE tickets " +
                            "ADD COLUMN called_at INTEGER DEFAULT 0"
            );
        }
    }

    public boolean register(String email, String password) {

        ContentValues values = new ContentValues();
        values.put("email", email.trim().toLowerCase());
        values.put("password", password);

        return getWritableDatabase().insert(
                "users", null, values
        ) != -1;
    }

    public boolean login(String email, String password) {

        Cursor cursor = getReadableDatabase().rawQuery(
                "SELECT id FROM users WHERE email=? AND password=?",
                new String[]{
                        email.trim().toLowerCase(),
                        password
                }
        );

        boolean found = cursor.moveToFirst();
        cursor.close();

        return found;
    }

    public boolean autoCallNextWaitingTicket(String windowCode) {
        // Check if a ticket is currently being called or processed at this window.
        Cursor activeCursor = getReadableDatabase().rawQuery(
                "SELECT id FROM tickets WHERE window_code=? AND status IN ('Called', 'Arrived')",
                new String[]{windowCode}
        );
        boolean hasActiveCall = activeCursor.moveToFirst();
        activeCursor.close();

        if (hasActiveCall) {
            return false;
        }

        // Get the earliest waiting ticket (First Come, First Served).
        Cursor waitingCursor = getReadableDatabase().rawQuery(
                "SELECT queue_number FROM tickets " +
                        "WHERE window_code=? AND status='Waiting' " +
                        "ORDER BY id ASC LIMIT 1",
                new String[]{windowCode}
        );

        if (waitingCursor.moveToFirst()) {
            int queueNumToCall = waitingCursor.getInt(0);
            waitingCursor.close();

            callTicket(windowCode, queueNumToCall);
            return true;
        }

        waitingCursor.close();
        return false;
    }

    public int getOrCreateUserTicket(String email, String windowCode) {
        // 1. Check if user already has an active ticket for this window.
        Cursor cursor = getReadableDatabase().rawQuery(
                "SELECT queue_number FROM tickets " +
                        "WHERE user_email=? AND window_code=? " +
                        "AND status IN ('Waiting', 'Called', 'Arrived', 'Late')",
                new String[]{email, windowCode}
        );

        if (cursor.moveToFirst()) {
            int existingNumber = cursor.getInt(0);
            cursor.close();

            autoCallNextWaitingTicket(windowCode);
            return existingNumber;
        }
        cursor.close();

        // 2. Find all active queue numbers for this window.
        Cursor activeCursor = getReadableDatabase().rawQuery(
                "SELECT queue_number FROM tickets " +
                        "WHERE window_code=? " +
                        "AND status IN ('Waiting', 'Called', 'Arrived', 'Late')",
                new String[]{windowCode}
        );

        Set<Integer> occupiedNumbers = new HashSet<>();
        while (activeCursor.moveToNext()) {
            occupiedNumbers.add(activeCursor.getInt(0));
        }
        activeCursor.close();

        // 3. System chooses the lowest available queue number starting from 1.
        int availableNumber = 1;
        while (occupiedNumbers.contains(availableNumber)) {
            availableNumber++;
        }

        // 4. Clean up any previous completed/inactive record for this window and number.
        getWritableDatabase().delete(
                "tickets",
                "window_code=? AND queue_number=?",
                new String[]{windowCode, String.valueOf(availableNumber)}
        );

        // 5. Create new ticket for the system-assigned queue number.
        ContentValues values = new ContentValues();
        values.put("user_email", email);
        values.put("window_code", windowCode);
        values.put("queue_number", availableNumber);
        values.put("status", "Waiting");
        values.put("called_at", 0);

        getWritableDatabase().insert(
                "tickets", null, values
        );

        // 6. Automatically call next waiting ticket (FCFS) if window is ready.
        autoCallNextWaitingTicket(windowCode);

        return availableNumber;
    }

    public int createTicket(String email, String windowCode) {
        return getOrCreateUserTicket(email, windowCode);
    }

    public int getNextWaitingTicket(String windowCode) {
        Cursor cursor = getReadableDatabase().rawQuery(
                "SELECT queue_number FROM tickets " +
                        "WHERE window_code=? AND status='Waiting' " +
                        "ORDER BY id ASC LIMIT 1",
                new String[]{windowCode}
        );

        int nextNumber = -1;
        if (cursor.moveToFirst()) {
            nextNumber = cursor.getInt(0);
        }
        cursor.close();
        return nextNumber;
    }

    public void callTicket(String windowCode, int number) {

        ContentValues values = new ContentValues();
        values.put("status", "Called");
        values.put("called_at", System.currentTimeMillis());

        getWritableDatabase().update(
                "tickets",
                values,
                "window_code=? AND queue_number=?",
                new String[]{
                        windowCode,
                        String.valueOf(number)
                }
        );
    }

    public void markArrived(String windowCode, int number) {
        updateStatus(windowCode, number, "Arrived");
    }

    public void markLate(String windowCode, int number) {
        updateStatus(windowCode, number, "Late");
        autoCallNextWaitingTicket(windowCode);
    }

    public void completeTicket(String windowCode, int number) {
        updateStatus(windowCode, number, "Completed");
        autoCallNextWaitingTicket(windowCode);
    }

    public void updateStatus(
            String windowCode,
            int number,
            String status) {

        ContentValues values = new ContentValues();
        values.put("status", status);

        getWritableDatabase().update(
                "tickets",
                values,
                "window_code=? AND queue_number=?",
                new String[]{
                        windowCode,
                        String.valueOf(number)
                }
        );
    }

    public String getStatus(String windowCode, int number) {

        Cursor cursor = getReadableDatabase().rawQuery(
                "SELECT status FROM tickets " +
                        "WHERE window_code=? AND queue_number=?",
                new String[]{
                        windowCode,
                        String.valueOf(number)
                }
        );

        String status = "Available";

        if (cursor.moveToFirst()) {
            status = cursor.getString(0);
        }

        cursor.close();

        if ("Completed".equals(status)) {
            return "Available";
        }

        return status;
    }

    public long getCalledAt(String windowCode, int number) {

        Cursor cursor = getReadableDatabase().rawQuery(
                "SELECT called_at FROM tickets " +
                        "WHERE window_code=? AND queue_number=?",
                new String[]{
                        windowCode,
                        String.valueOf(number)
                }
        );

        long calledAt = 0;

        if (cursor.moveToFirst()) {
            calledAt = cursor.getLong(0);
        }

        cursor.close();
        return calledAt;
    }
}
